﻿using Microsoft.EntityFrameworkCore;
using PizzaUNAB.Infrastructure.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaUNAB.Testing
{
    public class TestDbFactory
    {
        public static PizzeriaDb CreateInMemoryDb()
        {
            var options = new DbContextOptionsBuilder<PizzeriaDb>().UseInMemoryDatabase(Guid.NewGuid().ToString()).Options;

            var db = new PizzeriaDb(options);
            return db;
        }

    }
}
