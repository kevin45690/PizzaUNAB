﻿using PizzaUNAB.Application.DTOs;
using PizzaUNAB.Infrastructure.Data;
using PizzaUNAB.Infrastructure.Services;

namespace PizzaUNAB.Testing
{
    public class PizzaServiceIntegrationTest
    {
        private PizzeriaDb CreateDb()
        {
            return TestDbFactory.CreateInMemoryDb();
        }

        [SetUp]
        public async Task CrearPizza_DeberiaGuardarEnBD()
        {
            using var db = CreateDb();
            var service = new PizzaService(db);
            var dto = new PizzaCreateDto
            {
                Nombre = "jamon",
                Precio = 5.99m,
                Stock = 10

            };
            var id = await service.CreateAsync(dto);
            var Pizza = await service.GetByIdAsync(id);


            Assert.NotNull(Pizza);
            Assert.Equals("jamon", Pizza.Nombre);
            Assert.Equals(5.99m, Pizza.Precio);
            Assert.Equals(10, Pizza.Stock);
        }
        [SetUp]
        public async Task ActualizarPizza_DeberiaDeModificarLosDatosEnBD()
        {
            using var db = CreateDb();
            var service = new PizzaService(db);
            var id = await service.CreateAsync(new PizzaCreateDto { Nombre = "Pepperoni", Precio = 6, Stock = 5});

            var ok = await service.UpdateAsync(id, new PizzaUpdateDto{Nombre = " Pepperoni Especial", Precio = 6.99m, Stock = 8});
            var PizzaModificada = await service.GetByIdAsync(id);




            Assert.True(ok);
            Assert.NotNull(PizzaModificada);
            Assert.Equals("Pepperoni Especial", PizzaModificada.Nombre);



        }
        [SetUp]
        public async Task EliminarPizza_DeberiaEliminarDeBD()
        {
            using var db = CreateDb();
            var service = new PizzaService(db);
            var id = await service.CreateAsync(new PizzaCreateDto { Nombre = "Hawaiana", Precio = 8, Stock = 3 });



            var ok = await service.DeleteAsync(id);
            var PizzaEliminada = await service.GetByIdAsync(id);




            Assert.True(ok);
            Assert.Null(PizzaEliminada);
        }
    }
}
