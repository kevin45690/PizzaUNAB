﻿namespace PizzaUNAB.Application
{
    public class Class1
    {

    }
}
