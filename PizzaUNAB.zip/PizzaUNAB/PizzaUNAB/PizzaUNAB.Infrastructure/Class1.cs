﻿namespace PizzaUNAB.Infrastructure
{
    public class Class1
    {

    }
}
