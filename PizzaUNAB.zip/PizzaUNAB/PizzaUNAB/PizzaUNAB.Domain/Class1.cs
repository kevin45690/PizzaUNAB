﻿namespace PizzaUNAB.Domain
{
    public class Class1
    {

    }
}
